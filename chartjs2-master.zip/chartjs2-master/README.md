# chartjs2
ChartJS 2.x project code

# Tutorial
[Click here](https://www.dyclassroom.com/chartjs/getting-started) for the tutorial Notes
